# Auditoria pré-lançamento — Copiloto Financeiro

Data: 02/11/2026  
Escopo: revisão estática do frontend, leitura do projeto Supabase, alterações de segurança/integridade e testes técnicos limitados.

## O que foi alterado

### Banco de dados e segurança
- `criar_convite`: aceita somente `editor` e `leitor`, valida o e-mail informado e exige permissão de edição na família.
- `aceitar_convite`: bloqueia consumo simultâneo do código, verifica e-mail quando o convite é restrito e não consome convite sem perfil válido.
- `admin_liberar_familia`: valida a quantidade de dias (1 a 3650) e a existência da família.
- `pagamentos_informar`: só aceita o preço configurado, status pendente, identidade do usuário autenticado e dados de pagador com tamanho válido.
- `lancamentos`: políticas de inserção/edição/exclusão exigem mês aberto e vínculo correto entre mês e família.
- `lancamentos`: valor precisa ser positivo e os campos de parcelamento precisam ser consistentes.
- `gerar_recorrencias`, `pagar_todas_contas`, `dividir_lancamento`, `apagar_mes` e `desfazer`: validam o estado do mês e/ou os parâmetros antes de alterar os dados.
- `apagar_todos_meses`: mantém exclusão global do ano sob permissão do dono.
- `confirmar_importacao`: valida família, mês aberto, tipo, descrição, valor e data dos itens importados.
- `exportar_familia`: aumenta a entropia dos novos códigos de compartilhamento.

### Aplicativo
- Compras parceladas de 2 a 30 vezes são criadas pela RPC `criar_parcelado_v2`, em transação única.
- O valor total é distribuído em centavos e eventual diferença fica na última parcela.
- A tela permite excluir somente uma parcela ou o grupo completo.
- A planilha fica somente leitura quando o mês está fechado.
- O Service Worker usa cache `copiloto-v3` e inclui o ícone maskable.
- A tela e a política de privacidade deixam claro que o módulo de IA está desativado no backend neste momento.

## Testes realizados

- JavaScript: `node --check` sem erros.
- ZIP: integridade verificada com `unzip -t`.
- Parcelamento Supabase: teste temporário de R$ 100,00 em 3 parcelas; conferidos valores R$ 33,33, R$ 33,33 e R$ 33,34 e vencimentos de 31/01/2027, 28/02/2027 e 31/03/2027. Os três lançamentos de teste foram apagados; consulta posterior confirmou zero registros com a descrição de teste.
- Convite: tentativa com papel `dono` foi rejeitada pela função.
- Dados existentes: nenhuma parcela inconsistente ou lançamento com valor zero/negativo foi encontrado na checagem realizada.

## Pendências antes de vender

1. Revisar individualmente as 43 funções `SECURITY DEFINER` ainda acessíveis a `authenticated`. O advisor não encontrou nenhuma delas executável por `anon`, mas o alerta para usuários autenticados permanece até a revisão completa.
2. Ativar Leaked Password Protection nas configurações de Auth do Supabase.
3. Fazer testes reais com duas contas independentes, incluindo isolamento entre famílias, convites, fechamento/reabertura, importação e exclusão de conta.
4. O SDK Supabase JS no HTML está fixado em `2.45.4`, antigo em relação à versão atual. Atualizar somente após regressão de Auth, Realtime, Functions e Data API.
5. O Copiloto de IA está desligado no backend. Não anunciar como ativo nem enviar dados a um provedor até implementar, proteger e testar a integração.
6. A exclusão de conta existe dentro do app. A página externa `excluir-conta.html` foi preparada com instruções e contato por e-mail, mas ainda precisa ser publicada em uma hospedagem pública e ter sua URL validada antes de informar no Google Play Console.
7. `contato_email` foi preenchido no Supabase com `gustavosena972@gmail.com`, informado pelo responsável, para suporte e privacidade. Ainda é necessário confirmar que a caixa recebe mensagens e publicar a página externa de exclusão de conta. `operador_cnpj` continua vazio e `operador_nome` está preenchido apenas como “gustavo”; definir os dados legais/comerciais corretos antes de publicar. Revisar Termos e Política com profissional habilitado.
8. Publicar a Política de Privacidade em URL pública e preparar a declaração Data safety.
9. Concluir a declaração de recursos financeiros no Play Console.
10. O acesso pago é um serviço digital usado dentro do app. Para a versão Play Store, o Pix atual não pode simplesmente permanecer como único fluxo de compra: usar Google Play Billing ou, se elegível, inscrever-se no programa de faturamento alternativo aplicável ao Brasil e cumprir seus requisitos de integração e reporte.
11. Criar o app Android (por exemplo, Trusted Web Activity), configurar Digital Asset Links (`/.well-known/assetlinks.json`), gerar e assinar Android App Bundle e executar testes em dispositivos reais.
12. Criar uma trilha de migrations versionadas para que as alterações do banco sejam reproduzíveis em outro ambiente. As alterações desta revisão foram aplicadas diretamente no projeto conectado.
13. Fazer backup e testar restauração antes do primeiro cliente pagante.

## Limitações desta auditoria

Não foi realizado teste completo em navegador real, em dispositivos Android/iOS, nem teste de pagamento real. A análise do banco foi feita com consultas e verificações técnicas; isso não substitui um pentest independente nem uma revisão jurídica/LGPD.
