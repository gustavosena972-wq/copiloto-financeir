# Copiloto Financeiro — pacote para hospedar

Pasta pronta para publicar como site no GitHub Pages e instalar no celular (PWA).

## Publicar gratuitamente no GitHub Pages

1. Crie um repositório público no GitHub (por exemplo, `copiloto-financeiro`).
2. Envie **todos os arquivos e pastas deste pacote** para a raiz do repositório, mantendo a estrutura (`index.html`, `excluir-conta.html`, `icons/` etc.).
3. No GitHub, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
6. Aguarde a publicação. O endereço normalmente ficará no formato `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`.

Depois de publicado, a página de exclusão ficará em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/excluir-conta.html`. Substitua os exemplos pelo endereço real do repositório e teste a página em uma janela anônima.

**Atenção:** o GitHub Pages não aplica o arquivo `_headers`; ele é mantido no pacote para plataformas que reconhecem esse formato, mas não configura cabeçalhos de segurança no GitHub Pages. Não publique dados, chaves privadas ou arquivos `.env` no repositório.

## Antes de vender
- Entre como administrador, aba **Admin → Configurações do negócio**: preencha nome do responsável, CNPJ e e-mail de contato (aparecem nos Termos e na Política) e confira a chave Pix.
- Escaneie o QR de cobrança com **outro banco** para conferir o nome e o valor.
- Peça a um advogado para revisar os Termos de Uso e a Política de Privacidade.
- Supabase: use o plano pago (sem pausa automática e com backup) e ative a proteção contra senhas vazadas.

## Arquivos
- `index.html` — o aplicativo web
- `excluir-conta.html` — página pública de instruções para solicitar exclusão da conta (ainda precisa ser publicada e ter sua URL validada)
- `manifest.webmanifest`, `sw.js`, `icons/` — instalação PWA no celular
- `_headers` — cabeçalhos para hospedagens compatíveis; o GitHub Pages ignora esse arquivo

## Revisão técnica — 02/11/2026
- Convites agora aceitam somente os papéis `editor` e `leitor`; convites com papel `dono` são recusados no banco. O aceite verifica e-mail quando o convite é restrito a um endereço e bloqueia consumo simultâneo do mesmo código.
- Parcelamentos de 2 a 30 vezes usam a RPC `criar_parcelado_v2`, que cria todas as parcelas em uma única transação, valida família/categoria/membro/mês aberto e distribui os centavos restantes na última parcela. A exclusão permite escolher uma parcela ou o grupo inteiro.
- O cadastro de uma despesa simples continua usando `garantir_mes` e inserção normal. Lançamentos agora exigem valor positivo e metadados de parcela consistentes.
- O Service Worker foi atualizado para `copiloto-v3` e inclui o ícone maskable.
- A criação de parcelas depende da função `public.criar_parcelado_v2` já instalada no projeto Supabase.

## Limites atuais
- O PWA mantém a interface em cache, mas não oferece gravação financeira offline.
- O pedido Pix exige que o valor informado corresponda ao preço configurado; continua manual e o botão “Já paguei” não comprova recebimento. A aprovação continua restrita ao administrador e a liberação manual tem limite de dias.
- O módulo de IA está desativado no backend; a interface e a política de privacidade foram ajustadas para não afirmar que há envio atual de dados a um provedor externo de IA.
- Lançamentos em meses fechados ficam bloqueados por RLS; ações de recorrência, pagamento em massa, divisão e desfazer validam o estado do mês.
- O pacote não foi publicado nem submetido à Google Play.
- Antes de vender, conclua testes com contas separadas e revise privacidade, termos, suporte, backup e política de dados.
- Para Google Play, a página externa de solicitação de exclusão foi preparada em `excluir-conta.html`, mas ainda precisa ser publicada e ter sua URL validada. Também faltam URL pública da política de privacidade, declaração de recursos financeiros, pacote Android (por exemplo, Trusted Web Activity) e validação final do Data safety. A assinatura digital consumida dentro do app também precisa usar o Google Play Billing ou um programa de faturamento alternativo aprovado e integrado para o Brasil.
- `contato_email` foi definido no Supabase como `gustavosena972@gmail.com` para suporte e privacidade. Confirme que a caixa recebe mensagens e mantenha o endereço atualizado antes da publicação.


Consulte `AUDITORIA-PRE-LANCAMENTO.md` para o relatório detalhado, alterações realizadas, testes e pendências.
